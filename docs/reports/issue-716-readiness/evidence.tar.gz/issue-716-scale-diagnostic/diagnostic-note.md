# Issue 716 access scale probe

One diagnostic-only attempt against the copied #724 prototype snapshot. Instrumentation adds synchronous stderr records, so this run is for attribution only and is not a performance claim. The probe ran the existing 200 × 150 depot witness once with BUILD_BUDGETS=enforce under the bench machine lock, with a 10 second child timeout.

Outcome: timed out; exit code null; signal SIGKILL; elapsed 10037.9 ms.
